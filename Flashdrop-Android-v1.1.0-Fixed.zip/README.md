# Flashdrop Android v1.1.0

This version replaces the original `window.storage` signaling dependency with PeerJS signaling. The file transfer itself remains direct WebRTC data transfer.

The original HTML used `window.storage.set/get` to exchange WebRTC offers and answers. That API is not present in a normal Android WebView. PeerJS now handles that signaling step.

Build:
1. Upload this project to GitHub.
2. Open Actions.
3. Run **Build Flashdrop APK**.
4. Download **Flashdrop-v1.1.0-debug-apk**.
5. Install the APK on two phones.
6. On phone A choose Send and share the 6-character code.
7. On phone B choose Receive and enter/scan the code.
8. Select files on phone A and send.

Note: PeerJS is used only for signaling; the actual file bytes are sent through the WebRTC data connection.
